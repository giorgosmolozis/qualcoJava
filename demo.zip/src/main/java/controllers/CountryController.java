package controllers;

import Entities.Country;
import mappers.CountryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/countries")
public class CountryController {

    private final CountryMapper countryMapper;

    @Autowired
    public CountryController(CountryMapper countryMapper) {
        this.countryMapper = countryMapper;
    }

    @GetMapping
    public List<Country> getAllCountries() {
        return countryMapper.findAllCountries();
    }

    @GetMapping("/{id}")
    public Country getCountryById(@PathVariable("id") int countryId) {
        return countryMapper.findCountryById(countryId);
    }
}